import os
# 图片文件夹路径
pic_paths= "C:/Users/Lenovo/Desktop/yolov5/val/val2014/"
f=open('train.txt', 'w')
filenames=os.listdir(pic_paths)
filenames.sort()
for filename in filenames:
     # 图片绝对路径
    out_path="C:/Users/Lenovo/Desktop/yolov5/val/val2014/" + filename
    print(out_path)
    f.write(out_path+'\n')
f.close()